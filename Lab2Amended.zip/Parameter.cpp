//
// Created by Samuel Bennion on 2/18/21.
//

#include "Parameter.h"

std::string Parameter::toString() {
    return this->token->getData();
}
